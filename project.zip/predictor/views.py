import os, pickle
import pandas as pd
from django.shortcuts import render
from .forms import LoanForm
from .utils import proccess_data

# تحميل النموذج من مسار المشروع
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
model_path = os.path.join(BASE_DIR, 'model/endpoint_model.pkl')
with open(model_path, 'rb') as f:
    model = pickle.load(f)

def predict_loan(request):
    prediction = None
    if request.method == 'POST':
        form = LoanForm(request.POST)
        if form.is_valid():
            # بناء DataFrame من البيانات النظيفة
            data = form.cleaned_data
            df = pd.DataFrame([data])
            # معالجة وترميز
            df_proc = proccess_data(df)
            # التنبؤ
            pred = model.predict(df_proc)[0]
            prediction = 'Approved ✅' if pred in (1,'Y') else 'Rejected ❌'
    else:
        form = LoanForm()  # عرض القيم الافتراضية

    return render(request, 'predictor/form.html', {
  'form': form,
  'prediction': prediction
})

