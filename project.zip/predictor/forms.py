from django import forms

class LoanForm(forms.Form):
    Gender = forms.ChoiceField(choices=[('Male','Male'),('Female','Female')], initial='Male')
    Married = forms.ChoiceField(choices=[('Yes','Yes'),('No','No')], initial='Yes')
    Dependents = forms.ChoiceField(choices=[('0','0'),('1','1'),('2','2'),('3+','3+')], initial='0')
    Education = forms.ChoiceField(choices=[('Graduate','Graduate'),('Not Graduate','Not Graduate')], initial='Graduate')
    Self_Employed = forms.ChoiceField(choices=[('Yes','Yes'),('No','No')], initial='No')
    ApplicantIncome = forms.FloatField(initial=7000)
    CoapplicantIncome = forms.FloatField(initial=0.0)
    LoanAmount = forms.FloatField(initial=100.0)
    Loan_Amount_Term = forms.FloatField(initial=360.0)
    Credit_History = forms.ChoiceField(choices=[('1.0','1.0'),('0.0','0.0')], initial='1.0')
    Property_Area = forms.ChoiceField(choices=[('Urban','Urban'),('Semiurban','Semiurban'),('Rural','Rural')], initial='Urban')
