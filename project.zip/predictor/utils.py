import pandas as pd
from sklearn.preprocessing import LabelEncoder

def proccess_data(df):
    # تأكد أنك تستورد pandas في القمة
    if 'Loan_Status' in df.columns:
        df = df.drop(columns=['Loan_Status'])
    # المعالجة الأولية
    df['Gender'] = df['Gender'].fillna(df['Gender'].mode()[0])
    df['Married'] = df['Married'].fillna(df['Married'].mode()[0])
    df['Dependents'] = df['Dependents'].fillna(df['Dependents'].mode()[0])
    df['Self_Employed'] = df['Self_Employed'].fillna(df['Self_Employed'].mode()[0])
    df['LoanAmount'] = df['LoanAmount'].fillna(df['LoanAmount'].median())
    df['Loan_Amount_Term'] = df['Loan_Amount_Term'].fillna(df['Loan_Amount_Term'].mean())
    df['Credit_History'] = df['Credit_History'].fillna(df['Credit_History'].mode()[0])

    # الترميز LabelEncoder (بدون fit على النموذج الأصلي، لكن نقوم بنفس الترتيب)
    mapping = {
        'Gender': {'Female': 0, 'Male': 1},
        'Married': {'No': 0, 'Yes': 1},
        'Dependents': {'0': 0, '1': 1, '2': 2, '3+': 3},
        'Education': {'Not Graduate': 0, 'Graduate': 1},
        'Self_Employed': {'No': 0, 'Yes': 1},
        'Property_Area': {'Rural': 0, 'Semiurban': 1, 'Urban': 2},
    }
    for col, mp in mapping.items():
        df[col] = df[col].map(mp)

    return df
