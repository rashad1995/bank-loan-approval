from django.urls import path
from .views import predict_loan

urlpatterns = [
    path('', predict_loan, name='predict'),
]
